package id.marzz.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;\nimport net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;\nimport net.minecraft.entity.Entity;\nimport net.minecraft.util.hit.EntityHitResult;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Lightweight client HUD: keystrokes, FPS and player coordinates. */
public final class MarzzHud {
    private static final int PURPLE = 0xFFB78CFF;
    private static final int PANEL = 0xA91A1428;
    private static int jumpCount = 0;
    private static boolean wasOnGround = true;
    private MarzzHud() {}

    public static void register() {
        HudRenderCallback.EVENT.register(MarzzHud::render);
    }

    private static void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;
        int x = 8;
        int y = 8;
        if (MarzzHudConfig.showFps) {
            String fps = "FPS " + client.getCurrentFps();
            panel(context, x, y, client.textRenderer.getWidth(fps) + 12, 18);
            context.drawTextWithShadow(client.textRenderer, Text.literal(fps), x + 6, y + 5, 0xFFFFFFFF);
            y += 22;
        }
        if (MarzzHudConfig.showCoordinates) {
            String coords = String.format(java.util.Locale.ROOT, "XYZ %.1f / %.1f / %.1f",
                    client.player.getX(), client.player.getY(), client.player.getZ());
            panel(context, x, y, client.textRenderer.getWidth(coords) + 12, 18);
            context.drawTextWithShadow(client.textRenderer, Text.literal(coords), x + 6, y + 5, PURPLE);
        }
        if (MarzzHudConfig.showDirection) {
            float yaw = client.player.getYaw();
            String[] directions = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
            int index = Math.floorMod(Math.round(yaw / 45f) + 4, 8);
            String direction = "DIR " + directions[index];
            panel(context, x, y, client.textRenderer.getWidth(direction) + 12, 18);
            context.drawTextWithShadow(client.textRenderer, Text.literal(direction), x + 6, y + 5, PURPLE);
            y += 22;
        }
        if (MarzzHudConfig.showWorldClock && client.world != null) {
            long ticks = Math.floorMod(client.world.getTimeOfDay(), 24000L);
            int hour = (int) ((ticks / 1000L + 6L) % 24L);
            int minute = (int) ((ticks % 1000L) * 60L / 1000L);
            String clock = String.format(java.util.Locale.ROOT, "WORLD %02d:%02d", hour, minute);
            panel(context, x, y, client.textRenderer.getWidth(clock) + 12, 18);
            context.drawTextWithShadow(client.textRenderer, Text.literal(clock), x + 6, y + 5, PURPLE);
        }
        if (MarzzHudConfig.showTargetInfo && client.crosshairTarget instanceof EntityHitResult hit) {
            Entity target = hit.getEntity();
            String targetText = "TARGET " + target.getName().getString() + "  " + String.format(java.util.Locale.ROOT, "%.1fm", client.player.distanceTo(target));
            panel(context, x, y, client.textRenderer.getWidth(targetText) + 12, 18);
            context.drawTextWithShadow(client.textRenderer, Text.literal(targetText), x + 6, y + 5, 0xFFFFC7FF);
            y += 22;
        }
        if (MarzzHudConfig.showSpeed) {
            double velocity = client.player.getVelocity().horizontalLength() * 20.0;
            String speedText = String.format(java.util.Locale.ROOT, "SPEED %.2f m/s", velocity);
            panel(context, x, y, client.textRenderer.getWidth(speedText) + 12, 18);
            context.drawTextWithShadow(client.textRenderer, Text.literal(speedText), x + 6, y + 5, PURPLE);
            y += 22;
        }
        if (MarzzHudConfig.showJumpCount) {
            String jumps = "JUMPS " + jumpCount;
            panel(context, x, y, client.textRenderer.getWidth(jumps) + 12, 18);
            context.drawTextWithShadow(client.textRenderer, Text.literal(jumps), x + 6, y + 5, PURPLE);
            y += 22;
        }
        if (MarzzHudConfig.showPerformanceInfo) {
            Runtime runtime = Runtime.getRuntime();
            long usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024L * 1024L);
            long maxMb = runtime.maxMemory() / (1024L * 1024L);
            String memory = "MEM " + usedMb + "/" + maxMb + " MB";
            panel(context, x, y, client.textRenderer.getWidth(memory) + 12, 18);
            context.drawTextWithShadow(client.textRenderer, Text.literal(memory), x + 6, y + 5, PURPLE);
            y += 22;
        }
        if (MarzzHudConfig.showLowFpsWarning && client.getCurrentFps() < 30) {
            String warn = "LOW FPS  " + client.getCurrentFps();
            panel(context, x, y, client.textRenderer.getWidth(warn) + 12, 18);
            context.drawTextWithShadow(client.textRenderer, Text.literal(warn), x + 6, y + 5, 0xFFFF5555);
        }
        if (MarzzHudConfig.showKeystrokes) renderKeys(context, client);
    }

    private static void renderKeys(DrawContext context, MinecraftClient client) {
        int x = 8;
        int y = client.getWindow().getScaledHeight() - 76;
        int size = 20;
        key(context, client, x + size + 3, y, size, "W", GLFW.GLFW_KEY_W);
        key(context, client, x, y + size + 3, size, "A", GLFW.GLFW_KEY_A);
        key(context, client, x + size + 3, y + size + 3, size, "S", GLFW.GLFW_KEY_S);
        key(context, client, x + (size + 3) * 2, y + size + 3, size, "D", GLFW.GLFW_KEY_D);
        key(context, client, x, y + (size + 3) * 2, size * 2 + 3, "LMB", -1, GLFW.GLFW_MOUSE_BUTTON_1);
        key(context, client, x + (size + 3) * 2, y + (size + 3) * 2, size * 2 + 3, "RMB", -1, GLFW.GLFW_MOUSE_BUTTON_2);
    }

    private static void key(DrawContext context, MinecraftClient client, int x, int y, int size, String label, int key) {
        boolean down = key >= 0 && InputUtil.isKeyPressed(client.getWindow(), key);
        drawKey(context, x, y, size, size, label, down);
    }

    private static void key(DrawContext context, MinecraftClient client, int x, int y, int width, String label, int ignored, int mouseButton) {
        boolean down = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), mouseButton) == GLFW.GLFW_PRESS;
        drawKey(context, x, y, width, 20, label, down);
    }

    private static void drawKey(DrawContext context, int x, int y, int width, int height, String label, boolean down) {
        context.fill(x, y, x + width, y + height, down ? 0xE66B42B8 : PANEL);
        context.drawStrokedRectangle(x, y, width, height, down ? 0xFFFFC7FF : PURPLE);
        context.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, Text.literal(label),
                x + width / 2, y + 6, 0xFFFFFFFF);
    }

    private static void panel(DrawContext context, int x, int y, int width, int height) {
        context.fill(x, y, x + width, y + height, PANEL);
        context.fill(x, y, x + width, y + 1, PURPLE);
    }
}
