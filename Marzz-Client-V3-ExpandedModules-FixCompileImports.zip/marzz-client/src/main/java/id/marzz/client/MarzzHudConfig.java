package id.marzz.client;

/** Toggles for the Marzz on-screen HUD. */
public final class MarzzHudConfig {
    private MarzzHudConfig() {}
    public static boolean showKeystrokes = true;
    public static boolean showFps = true;
    public static boolean showCoordinates = true;
    public static boolean showDirection = true;
    public static boolean showWorldClock = false;
    public static boolean showTargetInfo = false;
    public static boolean showSpeed = false;
    public static boolean showJumpCount = false;
    public static boolean showLowFpsWarning = false;
    public static boolean showPerformanceInfo = false;
}
