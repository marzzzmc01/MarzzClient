package id.marzz.client;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Persists local client preferences in config/marzz-client.properties.
 * This only stores UI settings; it does not change network or anti-cheat behavior.
 */
public final class MarzzConfig {
    private static final String FILE_NAME = "marzz-client.properties";

    private MarzzConfig() {}

    public static void load() {
        Path file = getConfigPath();
        if (!Files.exists(file)) {
            save();
            return;
        }

        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(file)) {
            properties.load(input);

            StorageTracerConfig.enabled =
                    getBoolean(properties, "storage.enabled", StorageTracerConfig.enabled);
            StorageTracerConfig.showOutline =
                    getBoolean(properties, "storage.outline", StorageTracerConfig.showOutline);
            StorageTracerConfig.showTracer =
                    getBoolean(properties, "storage.tracer", StorageTracerConfig.showTracer);
            StorageTracerConfig.chest =
                    getBoolean(properties, "storage.chest", StorageTracerConfig.chest);
            StorageTracerConfig.enderChest =
                    getBoolean(properties, "storage.enderChest", StorageTracerConfig.enderChest);
            StorageTracerConfig.trappedChest =
                    getBoolean(properties, "storage.trappedChest", StorageTracerConfig.trappedChest);
            StorageTracerConfig.shulker =
                    getBoolean(properties, "storage.shulker", StorageTracerConfig.shulker);
            StorageTracerConfig.spawner =
                    getBoolean(properties, "storage.spawner", StorageTracerConfig.spawner);
            StorageTracerConfig.barrel =
                    getBoolean(properties, "storage.barrel", StorageTracerConfig.barrel);
            StorageTracerConfig.furnace =
                    getBoolean(properties, "storage.furnace", StorageTracerConfig.furnace);

            WorldAnalyzerConfig.chunkBorders =
                    getBoolean(properties, "world.chunkBorders", WorldAnalyzerConfig.chunkBorders);
            WorldAnalyzerConfig.exploredTerrainNotes =
                    getBoolean(properties, "world.exploredTerrainNotes", WorldAnalyzerConfig.exploredTerrainNotes);
            WorldAnalyzerConfig.showCoordinates =
                    getBoolean(properties, "world.showCoordinates", WorldAnalyzerConfig.showCoordinates);
            MarzzHudConfig.showKeystrokes = getBoolean(properties, "hud.keystrokes", MarzzHudConfig.showKeystrokes);
            MarzzHudConfig.showFps = getBoolean(properties, "hud.fps", MarzzHudConfig.showFps);
            MarzzHudConfig.showCoordinates = getBoolean(properties, "hud.coordinates", MarzzHudConfig.showCoordinates);
            MarzzHudConfig.showDirection = getBoolean(properties, "hud.direction", MarzzHudConfig.showDirection);
            MarzzHudConfig.showWorldClock = getBoolean(properties, "hud.worldClock", MarzzHudConfig.showWorldClock);
            MarzzHudConfig.showTargetInfo = getBoolean(properties, "combat.targetInfo", MarzzHudConfig.showTargetInfo);
            MarzzHudConfig.showSpeed = getBoolean(properties, "movement.speed", MarzzHudConfig.showSpeed);
            MarzzHudConfig.showJumpCount = getBoolean(properties, "movement.jumpCount", MarzzHudConfig.showJumpCount);
            MarzzHudConfig.showLowFpsWarning = getBoolean(properties, "optimizer.lowFpsWarning", MarzzHudConfig.showLowFpsWarning);
            MarzzHudConfig.showPerformanceInfo = getBoolean(properties, "optimizer.performanceInfo", MarzzHudConfig.showPerformanceInfo);
        } catch (IOException exception) {
            System.err.println("[Marzz Client] Could not load config: " + exception.getMessage());
        }
    }

    public static void save() {
        Properties properties = new Properties();

        properties.setProperty("storage.enabled", Boolean.toString(StorageTracerConfig.enabled));
        properties.setProperty("storage.outline", Boolean.toString(StorageTracerConfig.showOutline));
        properties.setProperty("storage.tracer", Boolean.toString(StorageTracerConfig.showTracer));
        properties.setProperty("storage.chest", Boolean.toString(StorageTracerConfig.chest));
        properties.setProperty("storage.enderChest", Boolean.toString(StorageTracerConfig.enderChest));
        properties.setProperty("storage.trappedChest", Boolean.toString(StorageTracerConfig.trappedChest));
        properties.setProperty("storage.shulker", Boolean.toString(StorageTracerConfig.shulker));
        properties.setProperty("storage.spawner", Boolean.toString(StorageTracerConfig.spawner));
        properties.setProperty("storage.barrel", Boolean.toString(StorageTracerConfig.barrel));
        properties.setProperty("storage.furnace", Boolean.toString(StorageTracerConfig.furnace));

        properties.setProperty("world.chunkBorders", Boolean.toString(WorldAnalyzerConfig.chunkBorders));
        properties.setProperty("world.exploredTerrainNotes", Boolean.toString(WorldAnalyzerConfig.exploredTerrainNotes));
        properties.setProperty("world.showCoordinates", Boolean.toString(WorldAnalyzerConfig.showCoordinates));
        properties.setProperty("hud.keystrokes", Boolean.toString(MarzzHudConfig.showKeystrokes));
        properties.setProperty("hud.fps", Boolean.toString(MarzzHudConfig.showFps));
        properties.setProperty("hud.coordinates", Boolean.toString(MarzzHudConfig.showCoordinates));
        properties.setProperty("hud.direction", Boolean.toString(MarzzHudConfig.showDirection));
        properties.setProperty("hud.worldClock", Boolean.toString(MarzzHudConfig.showWorldClock));
        properties.setProperty("combat.targetInfo", Boolean.toString(MarzzHudConfig.showTargetInfo));
        properties.setProperty("movement.speed", Boolean.toString(MarzzHudConfig.showSpeed));
        properties.setProperty("movement.jumpCount", Boolean.toString(MarzzHudConfig.showJumpCount));
        properties.setProperty("optimizer.lowFpsWarning", Boolean.toString(MarzzHudConfig.showLowFpsWarning));
        properties.setProperty("optimizer.performanceInfo", Boolean.toString(MarzzHudConfig.showPerformanceInfo));

        Path file = getConfigPath();
        try {
            Files.createDirectories(file.getParent());
            try (OutputStream output = Files.newOutputStream(file)) {
                properties.store(output, "Marzz Client local preferences");
            }
        } catch (IOException exception) {
            System.err.println("[Marzz Client] Could not save config: " + exception.getMessage());
        }
    }

    private static boolean getBoolean(Properties properties, String key, boolean fallback) {
        String value = properties.getProperty(key);
        return value == null ? fallback : Boolean.parseBoolean(value);
    }

    private static Path getConfigPath() {
        return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
    }
}
