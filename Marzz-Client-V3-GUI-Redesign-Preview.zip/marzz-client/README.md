# Marzz Client — V3 UI Preview

Client-side Fabric utility mod for Minecraft Java 1.21.11.

## Changes in this source update
- Control-center panel now has a smooth fade/settle opening animation and a brighter neon-violet accent.
- Existing HUD toggles and storage filters are retained.
- Settings continue to save to `config/marzz-client.properties`.

## Current limitations
- The storage ESP source still uses the standard `RenderLayers.lines()` pipeline. Through-wall rendering is **not fixed/verified** in this package.
- Storage markers scan loaded chunks within a 48-block horizontal radius and 24-block vertical range.
- Chunk borders and terrain notes are UI/config placeholders in this source, not implemented render features.

## Build
Use JDK 21. This project archive does not include the Gradle wrapper script/JAR; use the Gradle 9.2.0 setup from the previously working GitHub Actions workflow.

## Controls
- Right Shift: open the menu.
