package id.marzz.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class MarzzMenuScreen extends Screen {
    private static final int PANEL = 0xF0141020;
    private static final int PANEL_INNER = 0xFF211A31;
    private static final int ACCENT = 0xFFB78CFF;
    private static final int MUTED = 0xFFB9ADC9;
    private static final int WHITE = 0xFFF7F2FF;

    private int panelLeft, panelTop, panelWidth, panelHeight;
    private float openAnimation = 0.0f;

    public MarzzMenuScreen() {
        super(Text.literal("Marzz Client"));
    }

    @Override
    protected void init() {
        clearChildren();
        panelWidth = Math.min(390, width - 24);
        panelHeight = Math.min(326, height - 20);
        panelLeft = (width - panelWidth) / 2;
        panelTop = (height - panelHeight) / 2;

        int gap = 8;
        int colWidth = (panelWidth - 36 - gap) / 2;
        int left = panelLeft + 10;
        int right = left + colWidth + gap;
        int y = panelTop + 61;

        section("HUD", y);
        y += 17;
        addToggle(left, y, colWidth, "Keystrokes", () -> MarzzHudConfig.showKeystrokes, v -> MarzzHudConfig.showKeystrokes = v);
        addToggle(right, y, colWidth, "FPS Counter", () -> MarzzHudConfig.showFps, v -> MarzzHudConfig.showFps = v);
        y += 24;
        addToggle(left, y, colWidth, "Coordinates HUD", () -> MarzzHudConfig.showCoordinates, v -> MarzzHudConfig.showCoordinates = v);

        y += 30;
        section("WORLD TOOLS", y);
        y += 17;
        addToggle(left, y, colWidth, "Chunk Borders", () -> WorldAnalyzerConfig.chunkBorders, v -> WorldAnalyzerConfig.chunkBorders = v);
        addToggle(right, y, colWidth, "Terrain Notes", () -> WorldAnalyzerConfig.exploredTerrainNotes, v -> WorldAnalyzerConfig.exploredTerrainNotes = v);
        y += 24;
        addToggle(left, y, colWidth, "World Coordinates", () -> WorldAnalyzerConfig.showCoordinates, v -> WorldAnalyzerConfig.showCoordinates = v);

        y += 30;
        section("STORAGE FILTERS", y);
        y += 17;
        addToggle(left, y, colWidth, "Storage Tracer", () -> StorageTracerConfig.enabled, v -> StorageTracerConfig.enabled = v);
        addToggle(right, y, colWidth, "Chest", () -> StorageTracerConfig.chest, v -> StorageTracerConfig.chest = v);
        y += 24;
        addToggle(left, y, colWidth, "Ender Chest", () -> StorageTracerConfig.enderChest, v -> StorageTracerConfig.enderChest = v);
        addToggle(right, y, colWidth, "Trapped Chest", () -> StorageTracerConfig.trappedChest, v -> StorageTracerConfig.trappedChest = v);
        y += 24;
        addToggle(left, y, colWidth, "Shulker Box", () -> StorageTracerConfig.shulker, v -> StorageTracerConfig.shulker = v);
        addToggle(right, y, colWidth, "Spawner", () -> StorageTracerConfig.spawner, v -> StorageTracerConfig.spawner = v);
        y += 24;
        addToggle(left, y, colWidth, "Barrel", () -> StorageTracerConfig.barrel, v -> StorageTracerConfig.barrel = v);
        addToggle(right, y, colWidth, "Furnace", () -> StorageTracerConfig.furnace, v -> StorageTracerConfig.furnace = v);

        addDrawableChild(ButtonWidget.builder(Text.literal("CLOSE"), b -> close())
                .dimensions(panelLeft + panelWidth - 82, panelTop + panelHeight - 27, 72, 20).build());
    }

    private void section(String name, int y) {
        // Section labels are painted in render() so the controls remain keyboard-focusable.
    }

    private void addToggle(int x, int y, int w, String name,
                           java.util.function.BooleanSupplier getter,
                           java.util.function.Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(label(name, getter.getAsBoolean()), b -> {
            boolean next = !getter.getAsBoolean();
            setter.accept(next);
            MarzzConfig.save();
            b.setMessage(label(name, next));
        }).dimensions(x, y, w, 20).build());
    }

    private static Text label(String name, boolean enabled) {
        return Text.literal((enabled ? "●  " : "○  ") + name + "  " + (enabled ? "ON" : "OFF"));
    }

    // Disable the vanilla blurred background for this custom screen.
    // Screen.render() also invokes renderBackground(); allowing the default
    // blur here can request the blur effect twice in one frame.
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Intentionally empty: the menu draws its own layered background.
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Opening animation: ease-in opacity and a subtle vertical settling motion.
        openAnimation = Math.min(1.0f, openAnimation + Math.max(0.0f, delta) * 3.8f);
        float eased = openAnimation * openAnimation * (3.0f - 2.0f * openAnimation);
        int fade = Math.round(255 * eased);
        int slide = Math.round((1.0f - eased) * 7.0f);
        int top = panelTop + slide;
        // Layered panel, accent rail and inset surface give the menu depth without textures.
        context.fill(panelLeft - 3, top - 3, panelLeft + panelWidth + 3, top + panelHeight + 3, withAlpha(0x99000000, fade));
        context.fill(panelLeft, top, panelLeft + panelWidth, top + panelHeight, withAlpha(PANEL, fade));
        context.fill(panelLeft, top, panelLeft + panelWidth, top + 3, withAlpha(ACCENT, fade));
        context.fill(panelLeft + 1, top + 44, panelLeft + panelWidth - 1, top + 45, withAlpha(0xFF49375F, fade));
        context.fill(panelLeft + 8, top + 51, panelLeft + panelWidth - 8, top + panelHeight - 34, withAlpha(PANEL_INNER, fade));

        context.drawTextWithShadow(textRenderer, Text.literal("MARZZ"), panelLeft + 13, top + 12, WHITE);
        context.drawTextWithShadow(textRenderer, Text.literal("CLIENT  /  CONTROL CENTER"), panelLeft + 76, top + 14, ACCENT);
        context.drawTextWithShadow(textRenderer, Text.literal("RIGHT SHIFT  •  LOCAL SETTINGS"), panelLeft + 13, top + 30, MUTED);

        int labelX = panelLeft + 15;
        context.drawTextWithShadow(textRenderer, Text.literal("HUD"), labelX, top + 55, ACCENT);
        context.drawTextWithShadow(textRenderer, Text.literal("WORLD TOOLS"), labelX, top + 133, ACCENT);
        context.drawTextWithShadow(textRenderer, Text.literal("STORAGE FILTERS"), labelX, top + 211, ACCENT);

        super.render(context, mouseX, mouseY, delta);
    }

    // Helper used by the GUI opening fade animation.
    private static int withAlpha(int color, int fade) {
        int originalAlpha = (color >>> 24) & 0xFF;
        int newAlpha = originalAlpha * fade / 255;
        return (color & 0x00FFFFFF) | (newAlpha << 24);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
