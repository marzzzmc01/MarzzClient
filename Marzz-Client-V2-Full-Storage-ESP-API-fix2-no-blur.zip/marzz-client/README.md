# Marzz Client

Client-side Fabric utility mod for Minecraft Java 1.21.11.

## Features
- Right Shift opens the Marzz control center.
- HUD: FPS, coordinates, and keystrokes.
- Storage ESP: visible-only outline boxes and tracers for enabled chest, trapped chest, ender chest, barrel, shulker box, spawner, furnace, blast furnace, and smoker blocks.
- Storage ESP scans loaded blocks within 24 blocks horizontally and 12 blocks vertically, and checks line of sight before drawing. It intentionally does not reveal storage hidden behind solid blocks.
- Settings persist in `config/marzz-client.properties`.

## Build
Use JDK 21 and run `./gradlew build` (or `gradlew.bat build` on Windows). The Gradle wrapper JAR is not included in this source archive; generate/use a Gradle 8.14+ installation compatible with Fabric Loom 1.14.

## Controls
- Right Shift: open/close the menu.
