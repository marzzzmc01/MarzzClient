package id.marzz.client;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

/** Visible-only storage markers. Does not reveal blocks hidden behind solid terrain. */
public final class StorageEsp {
    private static final int SCAN_RADIUS = 24;
    private static final int VERTICAL_RADIUS = 12;
    private static final List<Marker> MARKERS = new ArrayList<>();
    private static int ticksUntilRefresh = 0;
    private record Marker(BlockPos pos, int color) {}
    private StorageEsp() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(StorageEsp::render);
    }

    public static void tick(MinecraftClient client) {
        if (ticksUntilRefresh-- > 0) return;
        ticksUntilRefresh = 10;
        MARKERS.clear();
        if (!StorageTracerConfig.enabled || client.player == null || client.world == null) return;
        BlockPos origin = client.player.getBlockPos();
        Vec3d eye = client.player.getEyePos();
        for (int x = origin.getX() - SCAN_RADIUS; x <= origin.getX() + SCAN_RADIUS; x++) {
            for (int y = Math.max(client.world.getBottomY(), origin.getY() - VERTICAL_RADIUS); y <= Math.min(client.world.getTopYInclusive(), origin.getY() + VERTICAL_RADIUS); y++) {
                for (int z = origin.getZ() - SCAN_RADIUS; z <= origin.getZ() + SCAN_RADIUS; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!client.world.isChunkLoaded(pos)) continue;
                    int color = colorFor(client.world.getBlockState(pos).getBlock());
                    if (color == 0 || client.player.squaredDistanceTo(Vec3d.ofCenter(pos)) > SCAN_RADIUS * SCAN_RADIUS) continue;
                    if (hasLineOfSight(client, eye, Vec3d.ofCenter(pos), pos)) MARKERS.add(new Marker(pos.toImmutable(), color));
                }
            }
        }
    }

    private static void render(net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!StorageTracerConfig.enabled || client.player == null || client.world == null
                || context.matrices() == null || context.consumers() == null) return;

        Vec3d camera = context.gameRenderer().getCamera().getCameraPos();
        Vec3d playerPos = client.player.getEntityPos();
        BlockPos origin = client.player.getBlockPos();
        MatrixStack matrices = context.matrices();
        VertexConsumer lines = context.consumers().getBuffer(RenderLayers.lines());
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        for (Marker marker : MARKERS) {
            BlockPos pos = marker.pos();
            int color = marker.color();
            BlockState state = client.world.getBlockState(pos);
            float r = ((color >> 16) & 255) / 255.0f;
            float g = ((color >> 8) & 255) / 255.0f;
            float b = (color & 255) / 255.0f;
            var shape = state.getOutlineShape(client.world, pos);
            int argb = color;
            VertexRendering.drawOutline(matrices, lines, shape,
                    pos.getX() - camera.x, pos.getY() - camera.y, pos.getZ() - camera.z,
                    argb, 1.5f);

            Vec3d start = client.player.getEyePos().subtract(camera);
            Vec3d end = Vec3d.ofCenter(pos).subtract(camera);
            lines.vertex(matrix, (float) start.x, (float) start.y, (float) start.z)
                    .color(r, g, b, 0.72f).normal(matrices.peek(), 0, 1, 0);
            lines.vertex(matrix, (float) end.x, (float) end.y, (float) end.z)
                    .color(r, g, b, 0.95f).normal(matrices.peek(), 0, 1, 0);
        }
    }

    private static boolean hasLineOfSight(MinecraftClient client, Vec3d camera, Vec3d target, BlockPos wanted) {
        HitResult hit = client.world.raycast(new RaycastContext(camera, target,
                RaycastContext.ShapeType.VISUAL, RaycastContext.FluidHandling.NONE, client.player));
        return hit.getType() == HitResult.Type.MISS
                || (hit.getType() == HitResult.Type.BLOCK && wanted.equals(((net.minecraft.util.hit.BlockHitResult) hit).getBlockPos()));
    }

    private static int colorFor(Block block) {
        if (block == Blocks.CHEST) return StorageTracerConfig.chest ? 0xFFD9A441 : 0;
        if (block == Blocks.ENDER_CHEST) return StorageTracerConfig.enderChest ? 0xFFB45CFF : 0;
        if (block == Blocks.TRAPPED_CHEST) return StorageTracerConfig.trappedChest ? 0xFFFF5555 : 0;
        if (block == Blocks.BARREL) return StorageTracerConfig.barrel ? 0xFFB98250 : 0;
        if (block == Blocks.SPAWNER) return StorageTracerConfig.spawner ? 0xFF55D6FF : 0;
        if (block == Blocks.FURNACE || block == Blocks.BLAST_FURNACE || block == Blocks.SMOKER)
            return StorageTracerConfig.furnace ? 0xFFB7C2D0 : 0;
        if (StorageTracerConfig.shulker && isShulker(block)) return 0xFFCB78E8;
        return 0;
    }

    private static boolean isShulker(Block block) {
        return block == Blocks.SHULKER_BOX || block == Blocks.WHITE_SHULKER_BOX
                || block == Blocks.ORANGE_SHULKER_BOX || block == Blocks.MAGENTA_SHULKER_BOX
                || block == Blocks.LIGHT_BLUE_SHULKER_BOX || block == Blocks.YELLOW_SHULKER_BOX
                || block == Blocks.LIME_SHULKER_BOX || block == Blocks.PINK_SHULKER_BOX
                || block == Blocks.GRAY_SHULKER_BOX || block == Blocks.LIGHT_GRAY_SHULKER_BOX
                || block == Blocks.CYAN_SHULKER_BOX || block == Blocks.PURPLE_SHULKER_BOX
                || block == Blocks.BLUE_SHULKER_BOX || block == Blocks.BROWN_SHULKER_BOX
                || block == Blocks.GREEN_SHULKER_BOX || block == Blocks.RED_SHULKER_BOX
                || block == Blocks.BLACK_SHULKER_BOX;
    }
}
