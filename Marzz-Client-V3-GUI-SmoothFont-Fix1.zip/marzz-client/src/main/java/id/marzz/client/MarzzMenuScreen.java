package id.marzz.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public final class MarzzMenuScreen extends Screen {
    private static final Identifier UI_FONT = Identifier.of("marzz_client", "ui");
    private static Text uiText(String value) { return Text.literal(value).styled(style -> style.withFont(new StyleSpriteSource.Font(UI_FONT))); }
    private static final int BG = 0xFF111116;
    private static final int PANEL = 0xFF19181F;
    private static final int INNER = 0xFF202027;
    private static final int ROW = 0xFF26252E;
    private static final int ROW_HOVER = 0xFF302B3B;
    private static final int PURPLE = 0xFFB78CFF;
    private static final int PURPLE_DARK = 0xFF7952A8;
    private static final int WHITE = 0xFFF4F0FA;
    private static final int MUTED = 0xFFAAA5B5;

    private final String[] categories = {"Combat", "World", "Visual", "Movement", "Player", "Misc", "Config", "Optimizer"};
    private int selectedCategory = 1;
    private long animationStartNanos;
    private float animation = 0f;
    private int panelX, panelY, panelW, panelH, sidebarW;
    private int contentX, contentW, rowY, rowH = 34;
    private boolean closing = false;

    private static final class ModuleEntry {
        final String title, description;
        final BooleanSupplier get;
        final Consumer<Boolean> set;
        ModuleEntry(String title, String description, BooleanSupplier get, Consumer<Boolean> set) {
            this.title = title; this.description = description; this.get = get; this.set = set;
        }
    }

    public MarzzMenuScreen() { super(Text.literal("Marzz Client")); }

    @Override protected void init() {
        animationStartNanos = System.nanoTime();
        animation = 0f;
        panelW = Math.min(760, Math.max(300, width - 24));
        panelH = Math.min(450, Math.max(250, height - 20));
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        sidebarW = Math.min(172, panelW / 3);
        contentX = panelX + sidebarW + 15;
        contentW = panelW - sidebarW - 28;
        rowY = panelY + 86;
        clearChildren();
    }

    private List<ModuleEntry> entries() {
        List<ModuleEntry> list = new ArrayList<>();
        switch (categories[selectedCategory]) {
            case "World" -> {
                list.add(new ModuleEntry("Storage Tracer", "Mark nearby storage blocks", () -> StorageTracerConfig.enabled, v -> StorageTracerConfig.enabled = v));
                list.add(new ModuleEntry("Chest filter", "Normal chests", () -> StorageTracerConfig.chest, v -> StorageTracerConfig.chest = v));
                list.add(new ModuleEntry("Ender Chest filter", "Ender chests", () -> StorageTracerConfig.enderChest, v -> StorageTracerConfig.enderChest = v));
                list.add(new ModuleEntry("Trapped Chest filter", "Trapped chests", () -> StorageTracerConfig.trappedChest, v -> StorageTracerConfig.trappedChest = v));
                list.add(new ModuleEntry("Shulker filter", "Shulker boxes", () -> StorageTracerConfig.shulker, v -> StorageTracerConfig.shulker = v));
                list.add(new ModuleEntry("Spawner filter", "Monster spawners", () -> StorageTracerConfig.spawner, v -> StorageTracerConfig.spawner = v));
                list.add(new ModuleEntry("Barrel filter", "Barrels", () -> StorageTracerConfig.barrel, v -> StorageTracerConfig.barrel = v));
                list.add(new ModuleEntry("Furnace filter", "Furnaces", () -> StorageTracerConfig.furnace, v -> StorageTracerConfig.furnace = v));
                list.add(new ModuleEntry("Chunk Borders", "Chunk boundary overlay", () -> WorldAnalyzerConfig.chunkBorders, v -> WorldAnalyzerConfig.chunkBorders = v));
                list.add(new ModuleEntry("Terrain Notes", "Local explored terrain notes", () -> WorldAnalyzerConfig.exploredTerrainNotes, v -> WorldAnalyzerConfig.exploredTerrainNotes = v));
                list.add(new ModuleEntry("World Coordinates", "Coordinates overlay", () -> WorldAnalyzerConfig.showCoordinates, v -> WorldAnalyzerConfig.showCoordinates = v));
            }
            case "Visual" -> {
                list.add(new ModuleEntry("Keystrokes HUD", "Show movement keys", () -> MarzzHudConfig.showKeystrokes, v -> MarzzHudConfig.showKeystrokes = v));
                list.add(new ModuleEntry("FPS Counter", "Display current frames per second", () -> MarzzHudConfig.showFps, v -> MarzzHudConfig.showFps = v));
                list.add(new ModuleEntry("Coordinates HUD", "Show player coordinates", () -> MarzzHudConfig.showCoordinates, v -> MarzzHudConfig.showCoordinates = v));
            }
            case "Config" -> { /* Config page is informational; all module changes save automatically. */ }
            default -> { }
        }
        return list;
    }

    private String subtitle() {
        return switch (categories[selectedCategory]) {
            case "World" -> "World overlays and storage markers";
            case "Visual" -> "HUD and visual preferences";
            case "Config" -> "Local configuration";
            case "Combat" -> "No modules available yet";
            case "Movement" -> "No modules available yet";
            case "Player" -> "Player ESP and nametags are not implemented yet";
            case "Misc" -> "Utility modules are not implemented yet";
            case "Optimizer" -> "Performance controls are not implemented yet";
            default -> "";
        };
    }

    private int alpha(int color, float progress) {
        int a = (color >>> 24) & 255;
        return (color & 0x00FFFFFF) | (Math.round(a * progress) << 24);
    }

    private int shiftedY(int y, float progress) { return y + Math.round((1f - progress) * 15f); }

    @Override public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) { }

    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        if (animationStartNanos == 0L) animationStartNanos = System.nanoTime();
        animation = Math.min(1f, (System.nanoTime() - animationStartNanos) / 300_000_000f);
        float eased = animation * animation * (3f - 2f * animation);
        int x = panelX, y = shiftedY(panelY, eased), w = panelW, h = panelH;
        context.fill(0, 0, width, height, alpha(0xA8000000, eased));
        context.fill(x - 3, y - 3, x + w + 3, y + h + 3, alpha(0xFF6F48A5, eased));
        context.fill(x, y, x + w, y + h, alpha(PANEL, eased));
        context.fill(x, y, x + w, y + 3, alpha(PURPLE, eased));
        context.fill(x, y + 3, x + sidebarW, y + h - 2, alpha(0xFF141419, eased));
        context.fill(x + sidebarW, y + 50, x + w - 1, y + 51, alpha(0xFF393641, eased));

        // Large, clean brand lockup: scaled UI text with a subtle double-pass for weight.
        context.getMatrices().pushMatrix();
        context.getMatrices().scale(1.65f, 1.65f);
        int logoX = Math.round((x + 17) / 1.65f);
        int logoY = Math.round((y + 8) / 1.65f);
        int logoColor = alpha(WHITE, eased);
        context.drawText(textRenderer, uiText("MARZZ"), logoX, logoY, logoColor, false);
        context.drawText(textRenderer, uiText("MARZZ"), logoX + 1, logoY, logoColor, false);
        context.getMatrices().popMatrix();
        context.fill(x + 18, y + 35, x + 83, y + 37, alpha(PURPLE, eased));
        context.drawText(textRenderer, uiText("CLIENT  /  CONTROL CENTER"), x + 98, y + 19, alpha(PURPLE, eased), false);
        context.drawText(textRenderer, uiText("V3  •  LOCAL"), x + w - 72, y + 14, alpha(MUTED, eased), false);

        int sidebarTop = y + 66;
        for (int i = 0; i < categories.length; i++) {
            int cy = sidebarTop + i * 31;
            boolean selected = i == selectedCategory;
            if (selected) {
                context.fill(x + 9, cy - 4, x + sidebarW - 9, cy + 23, alpha(0xFF30273C, eased));
                context.fill(x + 9, cy - 4, x + 12, cy + 23, alpha(PURPLE, eased));
            }
            context.drawText(textRenderer, uiText(categories[i]), x + 19, cy + 5, alpha(selected ? WHITE : MUTED, eased), true);
        }

        int cx = x + sidebarW + 17;
        context.drawText(textRenderer, uiText(categories[selectedCategory].toUpperCase()), cx, y + 64, alpha(WHITE, eased), true);
        context.drawText(textRenderer, uiText(subtitle()), cx, y + 78, alpha(MUTED, eased), true);
        context.fill(cx, y + 98, x + w - 15, y + 99, alpha(0xFF37333F, eased));

        List<ModuleEntry> current = entries();
        int listStart = y + 110;
        int availableBottom = y + h - 37;
        int usableHeight = Math.max(1, availableBottom - listStart);
        int rowStep = current.isEmpty() ? 34 : Math.max(26, Math.min(36, usableHeight / current.size()));
        int actualRowH = rowStep - 2;
        for (int i = 0; i < current.size(); i++) {
            ModuleEntry entry = current.get(i);
            int ry = listStart + i * rowStep;
            if (ry + actualRowH > availableBottom) break;
            boolean enabled = entry.get.getAsBoolean();
            boolean hovered = mouseX >= cx && mouseX <= x + w - 16 && mouseY >= shiftedY(ry, eased) && mouseY <= shiftedY(ry + actualRowH, eased);
            int drawY = shiftedY(ry, eased);
            context.fill(cx, drawY, x + w - 16, shiftedY(ry + actualRowH, eased), alpha(hovered ? ROW_HOVER : ROW, eased));
            // One-line module labels: removes the overlapping second-line description.
            context.drawText(textRenderer, uiText(entry.title), cx + 9, shiftedY(ry + (actualRowH - 9) / 2, eased), alpha(WHITE, eased), true);
            int toggleW = 32, toggleH = 16, sx = x + w - 52, sy = shiftedY(ry + (actualRowH - toggleH) / 2, eased);
            int track = enabled ? 0xFF875AC2 : 0xFF42414B;
            context.fill(sx, sy + 2, sx + toggleW, sy + toggleH - 2, alpha(track, eased));
            context.fill(sx + 2, sy, sx + toggleW - 2, sy + toggleH, alpha(track, eased));
            int knobX = enabled ? sx + toggleW - toggleH + 2 : sx + 2;
            context.fill(knobX, sy + 2, knobX + toggleH - 4, sy + toggleH - 2, alpha(enabled ? PURPLE : 0xFFB9B7C0, eased));
        }

        if (current.isEmpty()) {
            String message = categories[selectedCategory].equals("Player")
                    ? "Player ESP / Nametags are planned, not active yet."
                    : categories[selectedCategory].equals("Optimizer")
                    ? "Optimizer options are planned. No changes applied."
                    : categories[selectedCategory].equals("Config")
                    ? "All toggles save automatically to your local config."
                    : "This category has no active modules yet.";
            context.drawText(textRenderer, uiText(message), cx + 4, y + 126, alpha(MUTED, eased), true);
        }
        context.fill(x + 12, y + h - 29, x + w - 12, y + h - 28, alpha(0xFF37333F, eased));
        context.drawText(textRenderer, uiText("MARZZ CLIENT  •  SETTINGS SAVE LOCALLY"), x + 15, y + h - 19, alpha(MUTED, eased), true);
        context.drawText(textRenderer, uiText("ESC  CLOSE"), x + w - 70, y + h - 19, alpha(PURPLE, eased), true);
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();
        if (button != 0) return super.mouseClicked(click, doubled);
        float eased = animation * animation * (3f - 2f * animation);
        int y = shiftedY(panelY, eased);
        int sidebarTop = y + 66;
        for (int i = 0; i < categories.length; i++) {
            int cy = sidebarTop + i * 31;
            if (mouseX >= panelX + 9 && mouseX <= panelX + sidebarW - 9 && mouseY >= cy - 4 && mouseY <= cy + 23) {
                selectedCategory = i;
                return true;
            }
        }
        int cx = panelX + sidebarW + 17, listStart = y + 110, availableBottom = y + panelH - 37;
        List<ModuleEntry> current = entries();
        int usableHeight = Math.max(1, availableBottom - listStart);
        int rowStep = current.isEmpty() ? 34 : Math.max(26, Math.min(36, usableHeight / current.size()));
        int actualRowH = rowStep - 2;
        for (int i = 0; i < current.size(); i++) {
            ModuleEntry entry = current.get(i);
            int ry = listStart + i * rowStep;
            if (ry + actualRowH > availableBottom) break;
            int displayY = shiftedY(ry, eased);
            if (mouseX >= cx && mouseX <= panelX + panelW - 16 && mouseY >= displayY && mouseY <= shiftedY(ry + actualRowH, eased)) {
                entry.set.accept(!entry.get.getAsBoolean());
                MarzzConfig.save();
                return true;
            }
        }
        if (mouseX >= panelX + panelW - 84 && mouseY >= y + panelH - 29) {
            close();
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean shouldPause() { return false; }
}
