# Marzz Client V3 UI Update

This update uses bundled Inter Display OTF font providers for smooth UI text and logo, without matrix scaling.
The menu module list uses a two-column card layout with title/description and custom toggle rendering.
Existing working toggles are retained. Player ESP/Nametags and optimizer remain unimplemented in this ZIP.
Minecraft 1.21.11 / Fabric. Build with the existing GitHub Actions workflow.
